package Server;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

class DrawPanel extends JPanel {
    private int x1, y1, x2, y2;
    private String shape = "Pencil";
    private JTextField textField = new JTextField();
    private Shape tempShape = null;
    private Color currentColor = Color.BLACK;
    private java.util.List<Color> shapeColors = new ArrayList<>();
    private java.util.List<Color> textColors = new ArrayList<>();
    private java.util.List<Shape> shapes = new ArrayList<>();
    private java.util.List<String> texts = new ArrayList<>();
    private List<Point> textPoints = new ArrayList<>();
    Graphics2D g2;
    private static final double THRESHOLD = 1.0; // Distance Threshold for erasing

    public DrawPanel() {
        this.setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));

        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                x1 = e.getX();
                y1 = e.getY();
            }

            public void mouseReleased(MouseEvent e) {
                if (!shape.equals("Pencil")) {
                    addShape();
                }
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                x2 = e.getX();
                y2 = e.getY();
                if (shape.equals("Pencil")) {
                    shapes.add(new Line2D.Float(x1, y1, x2, y2));
                    shapeColors.add(currentColor);
                    repaint();
                    x1 = x2;
                    y1 = y2;
                } else if (shape.equals("Eraser")) {
                    eraseShape(new Point(x2, y2));
                    repaint();
                } else {
                    draw();
                }
            }
        });
        setBackground(Color.WHITE);
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        for (int i = 0; i < shapes.size(); i++) {
            g2.setColor(shapeColors.get(i));
            g2.draw(shapes.get(i));
        }

        for (int i = 0; i < texts.size(); i++) {
            g2.setColor(textColors.get(i));
            g2.drawString(texts.get(i), textPoints.get(i).x, textPoints.get(i).y);
        }

        if (tempShape != null) {
            g2.setColor(currentColor);
            g2.draw(tempShape);
        }
    }

    public void draw() {
        int diameter = Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1));
        switch (shape) {
            case "Line":
                tempShape = new Line2D.Double(x1, y1, x2, y2);
                break;
            case "Circle":
                tempShape = new Ellipse2D.Double(x1, y1, diameter, diameter);
                break;
            case "Oval":
                tempShape = new Ellipse2D.Float(x1, y1, x2 - x1, y2 - y1);
                break;
            case "Rectangle":
                tempShape = new Rectangle2D.Double(x1, y1, x2 - x1, y2 - y1);
                break;
            case "Text":
                textColors.add(currentColor);
                texts.add(textField.getText());
                textPoints.add(new Point(x1, y1));
                break;
        }
        repaint();
    }

    public void addShape() {
        if (tempShape != null) {
            shapeColors.add(currentColor);
            shapes.add(tempShape);
            tempShape = null;
        }
        repaint();
    }

    private void eraseShape(Point point) {
        for (int i = shapes.size() - 1; i >= 0; i--) {
            if (shapes.get(i).contains(point) || isNearLine(shapes.get(i), point)) {
                shapes.remove(i);
                shapeColors.remove(i);
                break;
            }
        }
        for (int i = textPoints.size() - 1; i >= 0; i--) {
            Rectangle textBound = new Rectangle(textPoints.get(i).x, textPoints.get(i).y - g2.getFontMetrics().getHeight(),
                    g2.getFontMetrics().stringWidth(texts.get(i)), g2.getFontMetrics().getHeight());
            if (textBound.contains(point)) {
                texts.remove(i);
                textPoints.remove(i);
                textColors.remove(i);
                break;
            }
        }
    }

    private boolean isNearLine(Shape shape, Point point) {
        if (shape instanceof Line2D) {
            Line2D line = (Line2D) shape;
            double distance = line.ptLineDist(point);
            return distance <= THRESHOLD;
        }
        return false;
    }

    public void setShape(String shape) {
        this.shape = shape;
        // Add these lines to change the cursor based on the shape
        switch (shape) {
            case "Pencil":
            case "Line":
            case "Circle":
            case "Oval":
            case "Rectangle":
                this.setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
                break;
            case "Text":
                this.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
                break;
            case "Eraser":
                this.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                break;
        }
    }

    public void clearWhiteboard() {
        shapes.clear(); // Remove all shapes
        shapeColors.clear(); // Remove all shape colors
        texts.clear(); // Remove all texts
        textPoints.clear(); // Remove all text positions
        textColors.clear(); // Remove all text colors
        repaint(); // Refresh the panel to reflect the changes
    };

    public void setTextField(String text){
        textField.setText(text);
    }

    public void setCurrentColor(Color color) {
        this.currentColor = color;
    }

    public Color getCurrentColor(){
        return this.currentColor;
    }

}